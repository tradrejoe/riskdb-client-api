# SensitivityApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSensitivity**](SensitivityApi.md#getSensitivity) | **GET** /api/Sensitivity | 

<a name="getSensitivity"></a>
# **getSensitivity**
> getSensitivity(date)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.SensitivityApi;


SensitivityApi apiInstance = new SensitivityApi();
OffsetDateTime date = new OffsetDateTime(); // OffsetDateTime | 
try {
    apiInstance.getSensitivity(date);
} catch (ApiException e) {
    System.err.println("Exception when calling SensitivityApi#getSensitivity");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **date** | **OffsetDateTime**|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

