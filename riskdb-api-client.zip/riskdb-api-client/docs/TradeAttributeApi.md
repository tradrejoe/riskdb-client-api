# TradeAttributeApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getTradeAttribute**](TradeAttributeApi.md#getTradeAttribute) | **GET** /api/TradeAttribute | 

<a name="getTradeAttribute"></a>
# **getTradeAttribute**
> getTradeAttribute(date)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.TradeAttributeApi;


TradeAttributeApi apiInstance = new TradeAttributeApi();
OffsetDateTime date = new OffsetDateTime(); // OffsetDateTime | 
try {
    apiInstance.getTradeAttribute(date);
} catch (ApiException e) {
    System.err.println("Exception when calling TradeAttributeApi#getTradeAttribute");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **date** | **OffsetDateTime**|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

